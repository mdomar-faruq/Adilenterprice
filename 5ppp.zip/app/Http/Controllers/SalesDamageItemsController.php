<?php

namespace App\Http\Controllers;

use App\Models\SalesDamageItems;
use Illuminate\Http\Request;

class SalesDamageItemsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SalesDamageItems $salesDamageItems)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalesDamageItems $salesDamageItems)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalesDamageItems $salesDamageItems)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalesDamageItems $salesDamageItems)
    {
        //
    }
}
